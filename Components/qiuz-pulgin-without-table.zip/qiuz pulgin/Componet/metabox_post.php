[
  wpqr_answers: [
    0: 'Text of the first answer',
    1: 'Text of the second answer',
    2: 'Text of the third answer',
  ],
  wpqr_points: [
    0: 0,
    1: 15,
    2: 10
  ]
]