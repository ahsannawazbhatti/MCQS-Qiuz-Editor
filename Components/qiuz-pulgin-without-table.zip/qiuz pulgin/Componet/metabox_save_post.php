<?php

// The saved array
array(
 0: array( 'text' => 'Text of the first answer',  'points' => 0 ),
 1: array( 'text' => 'Text of the second answer', 'points' => 15 ),
 2: array( 'text' => 'Text of the third answer',  'points' => 10 ),
)