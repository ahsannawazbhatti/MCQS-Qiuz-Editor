<?php

/**
 * Plugin Name: WordPress Quiz with React
 * Description: Quiz Plugin made by tutorial on ibenic.com
 * Plugin URI: https://ibenic.com
 */

if( ! defined( 'ABSPATH' ) ) {
    return;
}

class WPQR {

    public function includes() {
        include 'class-wpqr-metaboxes.php';
        include 'class-wpqr-rest-api.php';
    }
    /**
     * Load everything
     * @return void 
     */
    public function load() {
        add_action( 'init', array( $this, 'load_cpts' ) );
        add_action( 'init', array( $this, 'wpqr_flush_rewrite_rules' ) );
        add_action('init', array( $this, 'create_quiz_category_taxonomy' ));
        add_action( 'rest_api_init', array( 'WPQR_REST_API', 'register_routes' ) );
        if ( is_admin() ) { 
            add_action( 'add_meta_boxes', array( $this, 'register_metaboxes' ) );
            add_action( 'save_post', array( $this, 'save_metaboxes' ), 20, 2 );
        }
    } 
    function create_quiz_category_taxonomy() {
        $labels = array(
            'name' => 'Quiz Categories',
            'singular_name' => 'Quiz Category',
        );
    
        $args = array(
            'labels' => $labels,
            'hierarchical' => true,
        );
    
        register_taxonomy('quiz_category', 'mcqs', $args);
    }
    
    function wpqr_flush_rewrite_rules() {
        flush_rewrite_rules();
    }

    /**
     * Register all metaboxes
     * @return void 
     */
    public function register_metaboxes() {
        add_meta_box( 'question-answers', __( 'Options', 'wpqr' ), array( 'WPQR_Metaboxes', 'answers' ), 'mcqs' );
    }

    /**
     * Save all metaboxes if needed.
     * @param  integer $post_id 
     * @param  WP_Post $post    
     * @return void
     */
    public function save_metaboxes( $post_id, $post ) {
        WPQR_Metaboxes::save( $post_id, $post );
    }

    /**
     * Load all CPTs
     * @return void 
     */
    public function load_cpts() {
        $labels = array(
            'name'                  => _x( 'Questions', 'Post Type General Name', 'wpqr' ),
            'singular_name'         => _x( 'Question', 'Post Type Singular Name', 'wpqr' ),
            'menu_name'             => __( 'Questions', 'wpqr' ),
            'name_admin_bar'        => __( 'Question', 'wpqr' ),
            'archives'              => __( 'Item Archives', 'wpqr' ),
            'attributes'            => __( 'Item Attributes', 'wpqr' ),
            'parent_item_colon'     => __( 'Parent Item:', 'wpqr' ),
            'all_items'             => __( 'All Items', 'wpqr' ),
            'add_new_item'          => __( 'Add New Item', 'wpqr' ),
            'add_new'               => __( 'Add New', 'wpqr' ),
            'new_item'              => __( 'New Item', 'wpqr' ),
            'edit_item'             => __( 'Edit Item', 'wpqr' ),
            'update_item'           => __( 'Update Item', 'wpqr' ),
            'view_item'             => __( 'View Item', 'wpqr' ),
            'view_items'            => __( 'View Items', 'wpqr' ),
            'search_items'          => __( 'Search Item', 'wpqr' ),
            'not_found'             => __( 'Not found', 'wpqr' ),
            'not_found_in_trash'    => __( 'Not found in Trash', 'wpqr' ),
            'featured_image'        => __( 'Featured Image', 'wpqr' ),
            'set_featured_image'    => __( 'Set featured image', 'wpqr' ),
            'remove_featured_image' => __( 'Remove featured image', 'wpqr' ),
            'use_featured_image'    => __( 'Use as featured image', 'wpqr' ),
            'insert_into_item'      => __( 'Insert into item', 'wpqr' ),
            'uploaded_to_this_item' => __( 'Uploaded to this item', 'wpqr' ),
            'items_list'            => __( 'Items list', 'wpqr' ),
            'items_list_navigation' => __( 'Items list navigation', 'wpqr' ),
            'filter_items_list'     => __( 'Filter items list', 'wpqr' ),
        );
        $args = array(
            'label'                 => __( 'Question', 'wpqr' ),
            'description'           => __( 'Questions for Quiz', 'wpqr' ),
            'labels'                => $labels,
            'supports'              => array( 'title', 'editor' ),
            'hierarchical'          => false,
            'public'                => true,
            'show_ui'               => true,
            'show_in_menu'          => true,
            'menu_icon'             => 'dashicons-testimonial',
            'menu_position'         => 5,
            'show_in_admin_bar'     => true,
            'show_in_nav_menus'     => true,
            'show_in_rest'          => false,// Don't support Gutenberg
            'can_export'            => true, 
            'has_archive'           => false,
            'exclude_from_search'   => true,
            'publicly_queryable'    => true,
            'capability_type'       => 'page',
        );
        register_post_type( 'mcqs', $args );
    }
}

add_action( 'plugins_loaded', 'wpqr_load' );

/**
 * Loading our plugin
 * @return void 
 */
function wpqr_load() {
    $plugin = new WPQR();
    $plugin->includes();
    $plugin->load();
}
// ... Rest of the code